# Change Log

### 0.0.1

Initial release of vscode-discord

### 0.0.2

Rewritten Discord Register

### 0.0.3

* Removed Discord Registers for other Os than Windows.
* Added python support
* Added a VSCode disposable client, to let the Rich Presence reset when the process quit.

## 1.0.0

* First realease

* Removed Registry

* Added a new option: show debug

## 1.0.1

* Better Icon Mapping

* Patched time issue

* Made elapsed time toggel-able through `discord.showElapsedTime` setting