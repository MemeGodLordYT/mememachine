const settingsSchema = require("../../models/settings-schema");

const emoji = require("../../assets/json/tick-emoji.json");

module.exports = {
  aliases: ["mod-role"],
  memberName: "mod-role",
  group: "settings",
  description: "Add a moderator role in this server.",
  details:
    "If you provide a role that was already present in the database, the same role will be removed from the database of moderator roles.",
  format: "[@role | roleName | roleID]",
  examples: ["mod-role @Moderator"],
  userPermissions: ["MANAGE_GUILD"],
  singleArgs: true,
  cooldown: 3,
  guildOnly: true,
  callback: async (client, message, args) => {
    const guildId = message.guild.id;
    const role =
      message.mentions.roles.first() ||
      message.guild.roles.cache.find(
        (e) => e.name.toLowerCase().trim() == args.toLowerCase().trim()
      ) ||
      message.guild.roles.cache.find((e) => e.id === args);

    if (!role)
      return message.reply(
        emoji.missingEmoji + " No valid role found for the configuration."
      );

    const guildSettings = await settingsSchema.findOne({
      guildId,
    });

    if (
      guildSettings &&
      guildSettings.settings &&
      guildSettings.settings.modRoles
    ) {
      const arrayOfRoleIds = guildSettings.settings.modRoles;

      if (arrayOfRoleIds.some((roleId) => role.id === roleId)) {
        await settingsSchema.findOneAndUpdate(
          {
            guildId,
          },
          {
            guildId,
            $pull: {
              "settings.modRoles": role.id,
            },
          }
        );

        return message.reply(
          emoji.successEmoji +
            ` Removed the role **"${role.name}"** from the database of moderator roles.`
        );
      }
    }

    await settingsSchema.findOneAndUpdate(
      {
        guildId,
      },
      {
        guildId,
        $push: {
          "settings.modRoles": role.id,
        },
      },
      {
        upsert: true,
      }
    );

    message.reply(
      emoji.successEmoji +
        ` Added the role **"${role.name}"** to the database of moderator roles.`
    );
  },
};
