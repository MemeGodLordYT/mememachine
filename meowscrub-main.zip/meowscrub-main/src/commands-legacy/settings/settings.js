const Discord = require("discord.js");
const util = require("../../util/util");

const settingsSchema = require("../../models/settings-schema");

const emoji = require("../../assets/json/tick-emoji.json");

module.exports = {
  aliases: ["server-settings", "server-config", "server-conf", "guild-settings", "guild-config", "guild-conf"],
  memberName: "settings",
  group: "settings",
  description: "Shows all configurations set in the server.",
  userPermissions: ["MANAGE_GUILD"],
  cooldown: 3,
  guildOnly: true,
  callback: async (client, message) => {
    const guildSettings = await settingsSchema.findOne({
      guildId: message.guild.id,
    });

    if (!guildSettings || !guildSettings.settings)
      return message.reply(
        emoji.denyEmoji + " No configurations has been found for this server."
      );

    const settings = guildSettings.settings;

    const prefix = await util.getPrefix(message.guild.id);
    let dmPunishment = "";

    if (settings.dmPunishment) dmPunishment = "Yes";
    else dmPunishment = "No";

    let chatbotChannel = "None",
      suggestionChannel = "None",
      globalChat = "None";

    if (settings.chatbotChannel)
      chatbotChannel = `<#${settings.chatbotChannel}>`;
    if (settings.globalChat) globalChat = `<#${settings.globalChat}>`;
    if (settings.suggestionChannel)
      suggestionChannel = `<#${settings.suggestionChannel}>`;

    let ticketChannel = "None",
      ticketMessageId = "None",
      transcriptLog = "None";

    if (settings.ticketChannel && settings.ticketChannel.channelId) {
      ticketChannel = `<#${settings.ticketChannel.channelId}>`;
      ticketMessageId = settings.ticketChannel.messageId;
    }

    let muteRole = "None",
      modRoles = "None";

    if (settings.muteRole) muteRole = `<@&${settings.muteRole}>`;
    if (settings.modRoles && settings.modRoles.length > 0) {
      modRoles = "";
      for (const roleId of settings.modRoles) {
        modRoles += `<@&${roleId}> `;
      }
    }

    if (settings.transcriptLog) transcriptLog = `<#${settings.transcriptLog}>`;

    const embed = new Discord.MessageEmbed()
      .setColor("RANDOM")
      .setAuthor(
        `Configurations for: ${message.guild.name}`,
        message.guild.iconURL()
      )
      .addFields(
        {
          name: "Misc. Configuration",
          value: `
• Prefix: **${prefix}**
• DM Punishment Enabled: **${dmPunishment}**          
          `
        },
        {
          name: "Channel Configurations",
          value: `
• Chatbot: **${chatbotChannel}**            
• Suggestions Log: **${suggestionChannel}**
• Global Chat: **${globalChat}**
            `,
        },
        {
          name: "Ticket Configurations",
          value: `
• Ticket Channel: **${ticketChannel}**          
• Ticket Message ID: **${ticketMessageId}**
• Transcript Log: **${transcriptLog}**
          `,
        },
        {
          name: "Role-Related Configurations",
          value: `
• Mute Role: **${muteRole}**          
• Mod Roles: **${modRoles}**
          `,
        }
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  },
};
