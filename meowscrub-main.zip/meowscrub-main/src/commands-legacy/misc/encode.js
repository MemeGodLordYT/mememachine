const utf8 = require("utf8");
const base64 = require("base-64");
const morse = require("morse-decoder");

const util = require("../../util/util");

const emoji = require("../../assets/json/tick-emoji.json");

module.exports = {
  aliases: ["encode"],
  memberName: "encode",
  group: "misc",
  description: "Encode texts. That's it.",
  details: "All available encoders: `binary`, `base64`, `morse`",
  format: "<availableEncoders> <string>",
  examples: ["encode binary never", "encode base64 gonna", "encode morse give"],
  cooldown: 3,
  callback: async (client, message, args) => {
    const prefix = message.guild
      ? await util.getPrefix(message.guild.id)
      : client.settings.defaultPrefix;

    const chosenEncoder = args[0] ? args[0].toLowerCase() : args[0];
    if (!chosenEncoder)
      return message.reply(
        emoji.missingEmoji +
          ` You need to set an encoder in order to continue. Please use \`${prefix}help encode\` for details.`
      );

    const input = args[1] ? utf8.encode(args.slice(1).join(" ")) : "";
    if (!input)
      return message.reply(
        emoji.missingEmoji +
          " I can't do anything without any input. Try again."
      );

    function encodeInBinary(char) {
      return char
        .split("")
        .map((str) => {
          const encoded = str.charCodeAt(0).toString(2);
          return encoded.padStart(8, "0");
        })
        .join(" ");
    }

    let result = "";
    switch (chosenEncoder) {
      case "binary":
        result = encodeInBinary(input);
        break;
      case "base64":
        result = base64.encode(input);
        break;
      case "morse":
        result = morse.encode(input);
        break;
      default:
        return message.reply(
          emoji.denyEmoji +
            ` That's NOT a valid encoder. Please use \`${prefix}help encode\` for all available encoders.`
        );
    }

    if (result.length > 2000)
      return message.reply(
        emoji.denyEmoji +
          " The result has over 2000 characters, so I can't show it to you. Please try again with another input that's shorter."
      );

    message.channel.send(`\`\`\`\n${result}\n\`\`\``);
  },
};
