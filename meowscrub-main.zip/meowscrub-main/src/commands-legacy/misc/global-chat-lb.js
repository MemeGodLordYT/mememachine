const Discord = require("discord.js");

const globalChatSchema = require("../../models/global-chat-schema");
const botStaffSchema = require("../../models/bot-staff-schema");

module.exports = {
  aliases: ["global-chat-lb", "gc-lb"],
  memberName: "global-chat-lb",
  group: "economy",
  description: "Check top 10 richest members in the Global Chat leaderboard.",
  clientPermissions: ["EMBED_LINKS"],
  cooldown: 5,
  guildOnly: true,
  callback: async (client, message) => {
    function formatInt(int) {
      if (int < 10) return `0${int}`;
      return int;
    }

    const collection = new Discord.Collection();
    message.channel.send("Please wait...");

    const gcData = await globalChatSchema.find();
    const botStaff = await botStaffSchema.find();

    await Promise.all(
      gcData.map(async (data) => {
        const user = await client.users.fetch(data.userId);
        const userId = user.id;
        const messageCount = data.messageCount;
        let badgeDisplayed = "";

        if (client.isOwner(user)) {
          badgeDisplayed = "Dev   ";
        } else if (botStaff.some((staffData) => staffData.userId === userId)) {
          badgeDisplayed = "Staff ";
        } else if (messageCount < client.settings.msgCountForApproval) {
          badgeDisplayed = "Newbie";
        } else {
          badgeDisplayed = "Approv";
        }

        return messageCount !== 0
          ? collection.set(userId, {
              userId,
              messageCount,
              badgeDisplayed,
            })
          : null;
      })
    );

    const data = collection
      .sort((a, b) => b.messageCount - a.messageCount)
      .first(gcData.length + 1);

    let authorData = {};
    let authorDataString = "";
    data.forEach((d, i) => {
      if (d.userId === message.author.id)
        authorData = {
          index: i,
          ...d,
        };
    });

    if (Object.keys(authorData).length === 0)
      authorDataString = "**No data for you has been found.**";
    else
      authorDataString = `**#${authorData.index + 1}** • **${
        authorData.badgeDisplayed
      }** • **${authorData.messageCount.toLocaleString()}** • **${
        client.users.cache.get(authorData.userId).tag
      }**`;

    const data2 = collection
      .sort((a, b) => b.messageCount - a.messageCount)
      .first(10);

    let leaderboardMap = "";

    for (let i = 0; i < data2.length; i++) {
      const v = data2[i];
      leaderboardMap += `#${formatInt(i + 1)} • ${
        v.badgeDisplayed
      } • ${v.messageCount.toLocaleString()} • ${
        (await client.users.fetch(v.userId)).tag
      }\n`;
    }

    // data2
    //   .map((v, i) => {
    //     console.log(v.userId);
    //     return `#${formatInt(i + 1)} • ${
    //       v.badgeDisplayed
    //     } • ${v.messageCount.toLocaleString()} • ${
    //       (await client.users.fetch(v.userId)).tag
    //     }`;
    //   })
    //   .join("\n");

    if (collection.size === 0) leaderboardMap = "There's nothing here :(";

    const leaderboardEmbed = new Discord.MessageEmbed()
      .setColor("RANDOM")
      .setTitle("Top 10 most active in Global Chat")
      .setDescription(
        `**Current Rank:**\n${authorDataString}\n\`\`\`css\n${leaderboardMap}\`\`\``
      )
      .setFooter("The number indicates how many messages the person has sent.")
      .setTimestamp();
    message.channel.send({ embeds: [leaderboardEmbed] });
  },
};
