const utf8 = require("utf8");
const base64 = require("base-64");
const morse = require("morse-decoder");

const util = require("../../util/util");

const emoji = require("../../assets/json/tick-emoji.json");

module.exports = {
  aliases: ["decode"],
  memberName: "decode",
  group: "misc",
  description: "Decode texts. That's also it.",
  details: "All available decoders: `binary`, `base64`, `morse`",
  format: "<availableDecoders> <string>",
  examples: [
    "decode binary 01101110 01100101 01110110 01100101 01110010",
    "decode base64 Z29ubmE=",
    "decode morse --. .. ...- .",
  ],
  cooldown: 3,
  callback: async (client, message, args) => {
    const prefix = message.guild
      ? await util.getPrefix(message.guild.id)
      : client.settings.defaultPrefix;

    const chosenDecoder = args[0] ? args[0].toLowerCase() : args[0];
    if (!chosenDecoder)
      return message.reply(
        emoji.missingEmoji +
          ` You need to set a decoder in order to continue. Please use \`${prefix}help decode\` for details.`
      );

    const input = args[1] ? utf8.decode(args.slice(1).join(" ")) : "";
    if (!input)
      return message.reply(
        emoji.missingEmoji +
          " I can't do anything without any input. Try again."
      );

    function decodeInBinary(char) {
      return char
        .split(" ")
        .map((str) => String.fromCharCode(Number.parseInt(str, 2)))
        .join("");
    }

    let result = "";
    try {
      switch (chosenDecoder) {
        case "binary":
          result = decodeInBinary(input);
          break;
        case "base64":
          result = base64.decode(input);
          break;
        case "morse":
          result = morse.decode(input);
          break;
        default:
          return message.reply(
            emoji.denyEmoji +
              ` That's NOT a valid decoder. Please use \`${prefix}help decode\` for all available decoders.`
          );
      }
    } catch (err) {
      return message.reply(
        emoji.denyEmoji +
          " An error occured while decoding. Have you make sure that you've provided the proper input?"
      );
    }

    if (result.length > 2000)
      return message.reply(
        emoji.denyEmoji +
          " The result has over 2000 characters, so I can't show it to you. Please try again with another input that's shorter."
      );

    message.channel.send(`\`\`\`\n${result}\n\`\`\``);
  },
};
