module.exports = [
  {
    name: "obscure",
    chosenNumber: 6,
    rngCoins: 450,
  },
  {
    name: "fresh",
    chosenNumber: 4,
    rngCoins: 625,
  },
  {
    name: "funk",
    chosenNumber: 3,
    rngCoins: 750,
  },
  {
    name: "edgy",
    chosenNumber: 2,
    rngCoins: 800,
  },
  {
    name: "dead",
    chosenNumber: 5,
    rngCoins: 525,
  },
];
